package app;

import Ui.LoginFrame;

public class AidBridgeMain {
    public static void main(String[] args) {
        new LoginFrame();
    }
}
